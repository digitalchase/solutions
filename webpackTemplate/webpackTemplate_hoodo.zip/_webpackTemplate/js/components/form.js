import $ from "jquery";

function validEMail(sEmail) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(sEmail);
}

const validation = arr => {
    arr.map(el => {
        switch ($(el).data("validation")) {
            case "email":
                return validEMail($(el).val());
        }
    });
};

$("form").submit(function() {
    const that = $(this);
    const inputs = Array.from(that.find("input[data-validation]"));

    validation(inputs);
});
