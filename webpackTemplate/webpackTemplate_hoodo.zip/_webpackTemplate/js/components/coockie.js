import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";

if ($('[data-action="APPLY_COOCKIE"]').length) {
    $('[data-action="APPLY_COOCKIE"]').click(function() {
        dispatcher({
            type: "APPLY_COOCKIE"
        });
    });
}
