import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";

if ($("[data-accordion]").length) {
    const element = $('[data-action="ACCORDION_TOGGLE_DROPDOWN"]');
    element.on("click", function() {
        const that = $(this);
        const actionType = that.data("action");
        dispatcher({
            type: actionType,
            payload: {
                el: that
            }
        });
    });
}

if ($("[data-mobileCatalogAccardion]").length) {
    const elementMob = $('[data-action="MOBILE_CATALOG_ACCARDION"]');
    elementMob.on("click", function() {
        const that = $(this);
        const actionType = that.data("action");
        dispatcher({
            type: actionType,
            payload: {
                el: that
            }
        });
    });
}
