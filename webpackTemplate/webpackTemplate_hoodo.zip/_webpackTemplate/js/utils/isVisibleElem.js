import $ from "jquery";

export const isVisibleElem = el => {
    if (el.offset().top + el.innerHeight() / 2 > $(window).scrollTop()) {
        return true;
    } else {
        return false;
    }
};
