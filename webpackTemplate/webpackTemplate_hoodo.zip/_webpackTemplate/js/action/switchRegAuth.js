import $ from "jquery";

export const switchRegAuth = el => {
  const type = el.data("type");

  $("[data-form]").removeClass("active");
  // $('[data-form] input').val('');
  $(`[data-form="${type}"]`).addClass("active");
};
