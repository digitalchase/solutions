import $ from "jquery";
import { is } from "./../utils/prototypeCompare";
import throttle from "./../utils/throttle";

if ($("[_dc_customSelect]").length) {
    // Активация кастомного селекта
    const customSelect = $("[_dc_customSelect]");
    if (customSelect.length) {
        customSelect.dcInitCustomSelect();
    }
}

// toggle visibility header
(() => {
    const header = $(".header");

    function checkScrollDirection(callback) {
        let lastScrollTop = 0;

        $(window).on("scroll", function() {
            if ($(".popUp").is(".active")) {
                return false;
            }

            var top = $(window).scrollTop();
            if (lastScrollTop > top) {
                if (is("Function", callback.scrollTop)) {
                    callback.scrollTop();
                }
            } else if (lastScrollTop < top) {
                if (is("Function", callback.scrollDown)) {
                    callback.scrollDown();
                }
            }
            lastScrollTop = top;
        });
    }

    var callbackFuction = {
        scrollTop: function() {
            header.removeClass("hide");
        },
        scrollDown: function() {
            header.addClass("hide");
        }
    };

    checkScrollDirection(callbackFuction);
})();

(() => {
    const footer = $(".footer-wrapper");

    const paddingBottomPage = () => {
        $("body").css({
            paddingBottom: footer.innerHeight()
        });
    };

    paddingBottomPage();
    $(window).resize(throttle(paddingBottomPage, 1000));
})();

//footer change elem location
if ($("[data-footerSocialElem]").length) {
    (() => {
        function changeLocation() {
            const btnsElem = $("[data-footerSocialElem]"),
                descContainer = $("[data-descFooterSocialContainer]"),
                mobContainer = $("[data-mobFooterSocialContainer]");

            if (window.innerWidth > 750 && descContainer.find("*").length === 0) {
                descContainer.append(btnsElem);
            } else if (window.innerWidth <= 750 && mobContainer.find("*").length === 0) {
                mobContainer.append(btnsElem);
            }
        }

        changeLocation();
        $(window).resize(throttle(changeLocation, 1000));
    })();
}

// Доп класс для не пустых инпутов
(() => {
    $(document).on("input", "input", function() {
        const val = $(this).val();

        if (val.trim() !== "") {
            $(this).addClass("valid");
        } else {
            $(this).removeClass("valid");
        }
    });
})();
