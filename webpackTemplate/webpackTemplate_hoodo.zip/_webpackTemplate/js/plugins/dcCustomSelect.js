import jQuery from "jquery";
("use strict");
!(function(v) {
    var n = (function() {
        function t(t, e) {
            (this.el = this.is("String", t) ? v(t) : t),
                (this.uniqId = "dc" + Date.parse(new Date())),
                (this.select = v('[data-uniqId="' + this.uniqId + '"]')),
                (this.defaultOpitons = {
                    placeholder:
                        null != this.el.data("placeholder")
                            ? this.el.data("placeholder")
                            : "Выберите",
                    search: null != this.el.data("search"),
                    searchPlaceholder:
                        null != this.el.data("search-placeholder")
                            ? this.el.data("search-placeholder")
                            : "Поиск",
                    notFoundContent:
                        null != this.el.data("not-found-content")
                            ? this.el.data("not-found-content")
                            : "Совпадений не найдено",
                    baronScrollInit: null != this.el.data("baron-scroll-init"),
                    btnReset: null != this.el.data("btn-reset"),
                    multiple: null != this.el.data("multiple"),
                    multiplePlaceholder:
                        null != this.el.data("multiple-placeholder")
                            ? this.el.data("multiple-placeholder")
                            : void 0,
                    on: { dropdownOpen: null, dropdownClose: null }
                }),
                (this.state = { init: !1, dropdownIsOpen: !1 }),
                (this.uiComponent = {}),
                (this.options = this.is("Object", e)
                    ? Object.assign(this.defaultOpitons, e)
                    : this.defaultOpitons),
                0 == this.state.init && this.init();
        }
        var e = t.prototype;
        return (
            (e.is = function(t, e) {
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return null != e && n === t;
            }),
            (e.init = function() {
                var t = this.options.search;
                this.el.wrap('<div class="_dc_customSelect-wrapper" id="' + this.uniqId + '"/>'),
                    this.el.hide(),
                    this.createSelectUi(v("#" + this.uniqId)),
                    this.bindFunctionOnUi(),
                    this.outerClick(),
                    !0 === t && this.searchInit(),
                    (this.state.init = !0);
            }),
            (e.createSelectUi = function(t) {
                var e = this,
                    n = this.options,
                    s = n.placeholder,
                    i = n.search,
                    o = n.searchPlaceholder,
                    c = n.notFoundContent,
                    l = n.baronScrollInit,
                    d = n.btnReset,
                    a = n.multiple,
                    r = "",
                    _ = "",
                    u = "",
                    h = [];
                a
                    ? (t.addClass("_dc_customSelect-multiple"),
                      t.find("select").attr("multiple", ""),
                      Array.from(
                          t.find("select option").each(function(t, e) {
                              null != v(e).attr("value") &&
                                  h.push(
                                      '\n                                        <label class="_dc_customSelect__list_item">\n                                            <input type="checkbox" value="' +
                                          v(e).attr("value") +
                                          '">\n                                            <div class="_dc_customSelect__list_customCheckbox">\n                                                <div class="_dc_customSelect__list_customCheckbox_box"></div>\n                                                <div class="_dc_customSelect__list_customCheckbox_text">' +
                                          v(e).text() +
                                          "</div> \n                                            </div>\n                                        </label>\n                                    "
                                  );
                          })
                      ))
                    : Array.from(
                          t.find("select option").each(function(t, e) {
                              null != v(e).attr("value") &&
                                  h.push(
                                      '\n                                        <div class="_dc_customSelect__list_item ' +
                                          (0 === t ? "active" : "") +
                                          '" data-value="' +
                                          v(e).attr("value") +
                                          '">' +
                                          v(e).text() +
                                          "</div>\n                                    "
                                  );
                          })
                      ),
                    (r =
                        e.is("Function", window.baron) && !0 === l
                            ? '\n                                    <div class="_dc_customSelect__customScroll-wrapper">\n                                        <div class="_dc_customSelect__customScroll_scroller">\n                                            <div class="_dc_customSelect__list ' +
                              (d ? " _dc_customSelect__list-offsetBottom" : "") +
                              '">\n                                                ' +
                              h.join("") +
                              '\n                                            </div>\n                                        </div>\n                                        <div class="_dc_customSelect__customScroll_track ' +
                              (d ? " _dc_customSelect__customScroll_track-btnReset" : "") +
                              '">\n                                            <div class="_dc_customSelect__customScroll_bar"></div>\n                                        </div>\n                                    </div>\n                                '
                            : '\n                                    <div class="_dc_customSelect__list ' +
                              (d ? " _dc_customSelect__list-offsetBottom" : "") +
                              '">\n                                        ' +
                              h.join("") +
                              "\n                                    </div>\n                                "),
                    !0 === d &&
                        (_ =
                            '\n                                <div class="_dc_customSelect__btnReset">\n                                    <div class="_dc_customSelect__btnReset_icon"></div>\n                                    <div class="_dc_customSelect__btnReset_text">Сброс</div>\n                                    <div class="_dc_customSelect__btnReset_trigger"></div>\n                                </div>\n                            '),
                    i &&
                        (u =
                            '\n                                <div class="_dc_customSelect__search">\n                                    <div class="_dc_customSelect__search_input">\n                                        <input type="search" autocomplete="off" placeholder="' +
                            o +
                            '" />\n                                        <div class="_dc_customSelect__search_icon">\n                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">\n                                                <path d="M12.5 11H11.71L11.43 10.73C12.41 9.59 13 8.11 13 6.5C13 2.91 10.09 0 6.5 0C2.91 0 0 2.91 0 6.5C0 10.09 2.91 13 6.5 13C8.11 13 9.59 12.41 10.73 11.43L11 11.71V12.5L16 17.49L17.49 16L12.5 11ZM6.5 11C4.01 11 2 8.99 2 6.5C2 4.01 4.01 2 6.5 2C8.99 2 11 4.01 11 6.5C11 8.99 8.99 11 6.5 11Z" fill="#999999"/>\n                                            </svg>\n                                        </div>\n                                    </div>\n                                </div>\n                                <div class="_dc_customSelect__not-found" style="display: none">\n                                    ' +
                            c +
                            "\n                                </div>\n                            "),
                    t.append(
                        '\n                                <div class="_dc_customSelect__select">\n                                    <div class="_dc_customSelect__select_text"></div>\n                                    <div class="_dc_customSelect__trigger">\n                                        <div class="_dc_customSelect__trigger_arrow">\n                                            <svg width="9" height="5" viewBox="0 0 9 5" fill="none" xmlns="http://www.w3.org/2000/svg">\n                                                <path d="M8.354 4.30459C8.354 4.36492 8.32052 4.43279 8.2703 4.47804L7.85177 4.8551C7.80155 4.90035 7.72621 4.93051 7.65925 4.93051C7.59229 4.93051 7.51695 4.90035 7.46673 4.8551L4.17711 1.89141L0.887486 4.8551C0.837262 4.90035 0.761927 4.93051 0.694963 4.93051C0.619628 4.93051 0.552664 4.90035 0.502441 4.8551L0.0839138 4.47804C0.0336905 4.43279 0.000208855 4.36492 0.000208855 4.30459C0.000208855 4.24426 0.0336905 4.17639 0.0839138 4.13114L3.98458 0.616946C4.03481 0.571699 4.11014 0.541535 4.17711 0.541535C4.24407 0.541535 4.31941 0.571699 4.36963 0.616946L8.2703 4.13114C8.32052 4.17639 8.354 4.24426 8.354 4.30459Z" fill="#333333"/>\n                                            </svg>\n                                        </div>\n                                    </div>\n                                </div>\n                                <div class="_dc_customSelect__dropdown">\n                                    ' +
                            u +
                            "\n                                    " +
                            r +
                            "\n                                    " +
                            _ +
                            "\n                                </div>\n                            "
                    ),
                    e.is("Function", window.baron) &&
                        l &&
                        ((window.baronInit = []),
                        (window.baronInit[e.uniqId] = baron({
                            root: v("#" + e.uniqId + " ._dc_customSelect__customScroll-wrapper")
                                .selector,
                            scroller: "._dc_customSelect__customScroll_scroller",
                            bar: "._dc_customSelect__customScroll_bar",
                            scrollingCls: "_scrolling",
                            draggingCls: "_dragging"
                        })));
                var p = v("#" + this.uniqId);
                this.uiComponent = {
                    globalWrapper: p,
                    selectBox: p.find("._dc_customSelect__select"),
                    selectEl: p.find("select"),
                    selectPlaceholder: p.find("._dc_customSelect__select_text"),
                    dropdown: p.find("._dc_customSelect__dropdown"),
                    searchInput: p.find('[type="search"]'),
                    notFoundBlockMessage: p.find("._dc_customSelect__not-found"),
                    list: p.find("._dc_customSelect__list"),
                    listItems: p.find("._dc_customSelect__list_item"),
                    btnResetElement: p.find("._dc_customSelect__btnReset_trigger")
                };
                var m = this.uiComponent.selectEl;
                "" ===
                m
                    .find("option")
                    .eq(0)
                    .val()
                    .trim()
                    ? (e.setVal(""), e.updatePlaceholder(s))
                    : (e.setVal(
                          m
                              .find("option")
                              .eq(0)
                              .val()
                              .trim()
                      ),
                      e.updatePlaceholder(
                          m
                              .find("option")
                              .eq(0)
                              .text()
                              .trim()
                      ));
            }),
            (e.searchInit = function() {
                var t = this.uiComponent,
                    e = t.globalWrapper,
                    n = t.searchInput,
                    i = t.listItems,
                    o = t.notFoundBlockMessage;
                n.on("input", function() {
                    var s = v(this);
                    e.is(".notFound") && e.removeClass("notFound"),
                        i.each(function(t, e) {
                            var n = s.val().toLowerCase();
                            new RegExp(n, "i").test(
                                v(e)
                                    .text()
                                    .toLowerCase()
                            )
                                ? v(e).show()
                                : v(e).hide();
                        }),
                        0 ===
                        Array.from(i).filter(function(t) {
                            return v(t).is(":visible");
                        }).length
                            ? (o.show(), e.addClass("notFound"))
                            : o.is(":visible") && o.hide();
                });
            }),
            (e.bindFunctionOnUi = function() {
                var n,
                    s,
                    t = this.options,
                    e = t.on,
                    i = t.btnReset,
                    o = t.multiple,
                    c = t.placeholder,
                    l = t.multiplePlaceholder,
                    d = this.state.globalWrapper,
                    a = this.uiComponent,
                    r = a.selectBox,
                    _ = a.listItems,
                    u = a.btnResetElement,
                    h = a.selectEl,
                    p = (v("#" + this.uniqId), this);
                (r.on("click", function() {
                    var t = p.state.dropdownIsOpen;
                    t ? p.closeDropdown() : p.openDropdown(),
                        void 0 !== e &&
                            p.is("Object", e) &&
                            (p.is("Function", e.dropdownOpen) && t
                                ? e.dropdownOpen(d)
                                : p.is("Function", e.dropdownClose) && !t && e.dropdownClose(d));
                }),
                o)
                    ? _.on("click", function() {
                          var t;
                          v(this).toggleClass("active"),
                              _.find("input:checked").each(function(t, e) {
                                  v(e)
                                      .parent("._dc_customSelect__list_item")
                                      .addClass("active");
                              }),
                              p.setVal(v(this).attr("data-value")),
                              (n = []),
                              _.find("input:checked").each(function(t, e) {
                                  n.push(v(e).val());
                              }),
                              (s = []),
                              _.find("input:checked").each(function(t, e) {
                                  var n = v(e).parents("._dc_customSelect__list_item");
                                  s.push(
                                      n.find("._dc_customSelect__list_customCheckbox_text").text()
                                  );
                              }),
                              h.val(n),
                              (t =
                                  "" === s.join(", ").trim()
                                      ? c
                                      : null != l
                                      ? l
                                      : s.join(", ").trim()),
                              p.updatePlaceholder(t);
                      })
                    : _.on("click", function() {
                          p.setVal(v(this).attr("data-value")),
                              _.removeClass("active"),
                              v(this).addClass("active"),
                              p.updatePlaceholder(v(this).text()),
                              p.closeDropdown();
                      });
                u.length &&
                    i &&
                    u.on("click", function() {
                        p.resetValue();
                    });
            }),
            (e.outerClick = function() {
                this.options.on;
                var s = this.uiComponent.globalWrapper,
                    i = this;
                v(document).click(function(t) {
                    var e = i.state.dropdownIsOpen,
                        n = s;
                    !n.is(t.target) && 0 === n.has(t.target).length && e && i.closeDropdown();
                });
            }),
            (e.resetValue = function(t) {
                var e = this,
                    n = this.uiComponent,
                    s = n.btnResetElement,
                    i = n.listItems,
                    o = this.options,
                    c = o.placeholder,
                    l = o.multiple;
                s.on("click", function() {
                    e.setVal(""),
                        e.closeDropdown(),
                        e.updatePlaceholder(null != t ? t : c),
                        i.removeClass("active"),
                        l && i.find("input:checked").prop("checked", !1);
                });
            }),
            (e.openDropdown = function() {
                var t = this.options,
                    e = t.on,
                    n = t.baronScrollInit,
                    s = (this.state.dropdownIsOpen, this),
                    i = v("#" + this.uniqId);
                i
                    .find("._dc_customSelect__dropdown")
                    .css({ position: "absolute", top: i.innerHeight(), left: 0, width: "100%" }),
                    i.addClass("dropped"),
                    (this.state.dropdownIsOpen = !0),
                    s.is("Function", window.baron) &&
                        n &&
                        (i.find("._dc_customSelect__customScroll_scroller").height() >
                        i.find("._dc_customSelect__list").innerHeight()
                            ? i.find("._dc_customSelect__customScroll_track").hide()
                            : (i.find("._dc_customSelect__customScroll_track").show(),
                              window.baronInit[s.uniqId].update())),
                    void 0 !== e &&
                        s.is("Object", e) &&
                        s.is("Function", e.dropdownOpen) &&
                        i.is(".dropped") &&
                        e.dropdownOpen(s.el.parent());
            }),
            (e.closeDropdown = function() {
                var t = this.options,
                    e = t.on,
                    n = (t.multiple, this.state.dropdownIsOpen, this.uiComponent),
                    s = n.globalWrapper;
                n.listItems, n.selectEl;
                s.removeClass("dropped"),
                    s.find('[type="search"]').val(""),
                    s.find("._dc_customSelect__not-found").hide(),
                    s.removeClass("notFound"),
                    s.find("._dc_customSelect__list_item").show(),
                    (this.state.dropdownIsOpen = !1),
                    void 0 !== e &&
                        this.is("Object", e) &&
                        this.is("Function", e.dropdownClose) &&
                        !s.is(".dropped") &&
                        e.dropdownClose(this.el.parent());
            }),
            (e.setVal = function(t) {
                var e = this.uiComponent.selectEl;
                e.val(t), e.trigger("change");
            }),
            (e.updatePlaceholder = function(t) {
                this.uiComponent.selectPlaceholder.html(t);
            }),
            (e.getVal = function() {
                return this.uiComponent.selectEl.val();
            }),
            t
        );
    })();
    v.fn.dcInitCustomSelect = function(t) {
        var e = t;
        return this.each(function(t) {
            v(this).attr("data-uniqId", "dc" + Date.parse(new Date()) + t),
                new n(v(this), e ? e[t] : "");
        });
    };
})(jQuery);
