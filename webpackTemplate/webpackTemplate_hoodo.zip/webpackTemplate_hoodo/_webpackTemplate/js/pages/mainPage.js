import $ from "jquery";
import { isVisibleElem } from "./../utils/isVisibleElem";

const imageElem = $(`.mainPage__categoryImages`);
const anchorElem = $(".mainPage__nav_item");
const categoryTitle = $(".mainPage__content_categoryTitle");

anchorElem.on("click", function() {
    const index = $(this).data("index");
    $("body, html").animate(
        {
            scrollTop: $(`.mainPage__categoryItem[data-itemIndex="${index}"]`).offset().top
        },
        500
    );
});

imageElem.each((i, el) => {
    $(el).css({
        zIndex: i + 1
    });
});

function changeContent() {
    if (window.innerWidth <= 1150) {
        return false;
    }

    const elem = $(".mainPage__categoryItem");
    let currentIndex;
    elem.each((i, el) => {
        if ($(window).scrollTop() > elem.eq(elem.length - 1).offset().top) {
            currentIndex = elem.eq(elem.length - 1).data("itemindex");
            return false;
        }

        if (isVisibleElem($(el))) {
            currentIndex = $(el).data("itemindex");
            return false;
        }
    });

    const imageElemCurrent = $(`.mainPage__categoryImages[data-index="${currentIndex}"]`);
    const anchorElemCurrent = $(`.mainPage__nav_item[data-index="${currentIndex}"]`);
    const categoryTitleCurrent = $(
        `.mainPage__content_categoryTitle[data-index="${currentIndex}"]`
    );

    anchorElem.removeClass("active");
    imageElem.removeClass("active");
    categoryTitle.removeClass("active");

    imageElemCurrent.addClass("active");
    imageElemCurrent.prevAll(".mainPage__categoryImages").addClass("active");

    anchorElemCurrent.addClass("active");
    categoryTitleCurrent.addClass("active");
}

function categoryTitleAutoHeight() {
    if (window.innerWidth <= 650) {
        $(".mainPage__categoryItem_category").css({
            height: $(".mainPage__categoryItem_images").innerHeight()
        });
    } else {
        $(".mainPage__categoryItem_category").removeAttr("style");
    }
}

$(window).on("resize load", categoryTitleAutoHeight);
$(window).on("scroll load", changeContent);
