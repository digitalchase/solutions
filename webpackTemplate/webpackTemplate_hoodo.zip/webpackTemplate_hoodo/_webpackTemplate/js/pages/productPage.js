import $ from "jquery";
import throttle from "./../utils/throttle";

if ($(".productItem .colorRadioButton input").length) {
    (() => {
        const inputs = $(".productItem .colorRadioButton input");

        inputs.on("change", function() {
            const val = $(this).val();
            const colorBlockExample = $("[data-colorBlockExample]");
            const colors = $("[data-colorsExample]").data("colorsexample");
            const currentColor = colors[val];

            colorBlockExample.find("img").attr("src", currentColor);
        });
    })();
}

if ($("[data-btnsElem]").length) {
    (() => {
        function changeLocation() {
            const btnsElem = $("[data-btnsElem]"),
                descContainer = $("[data-descContainer]"),
                mobContainer = $("[data-mobContainer]");

            if (window.innerWidth >= 768 && descContainer.children().length === 0) {
                descContainer.append(btnsElem);
            } else if (window.innerWidth < 768 && mobContainer.children().length === 0) {
                mobContainer.append(btnsElem);
            }
        }

        changeLocation();
        $(window).resize(throttle(changeLocation, 1000));
    })();
}
