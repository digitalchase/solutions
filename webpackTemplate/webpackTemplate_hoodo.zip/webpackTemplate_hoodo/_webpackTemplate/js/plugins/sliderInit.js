import $ from "jquery";
import Swiper from "swiper";
import { is } from "./../utils/prototypeCompare";

let slidersObj = {};

// Слайдер в карточке товара вверху странице
if ($(".productItem__gallery").length) {
    (() => {
        slidersObj.productItem__gallery = {
            thumbs: 0,
            topSlider: 0
        };

        let { thumbs, topSlider } = slidersObj.productItem__gallery,
            slides = $(".productItem__gallery .gallery-thumbs .swiper-slide");

        function sliderInit() {
            if (thumbs === 0 && is("Object", thumbs) === false && (topSlider === 0 && is("Object", topSlider) === false)) {
                thumbs = new Swiper(".productItem__gallery .gallery-thumbs", {
                    slidesPerView: slides.length >= 6 ? 6 : slides.length,
                    direction: "vertical",
                    watchSlidesVisibility: true,
                    watchSlidesProgress: true
                });
            }

            topSlider = new Swiper(".productItem__gallery .gallery-top", {
                slidesPerView: "auto",
                // speed: 0,
                // centeredSlides: false,
                // loop: false,
                navigation: {
                    nextEl: ".productItem__gallery .swiper-button-next",
                    prevEl: ".productItem__gallery .swiper-button-prev"
                },
                thumbs: {
                    swiper: thumbs
                },
                breakpoints: {
                    1201: {
                        // slidesPerView: "auto",
                        centeredSlides: false,
                        loop: false,
                        speed: 0
                    },

                    320: {
                        // slidesPerView: 2.15,
                        centeredSlides: true,
                        loop: true,
                        speed: 500
                    }
                }
            });
        }

        function sliderItemAutoProperty() {
            const leftBtn = $("[data-autoPosition='left']"),
                rightBtn = $("[data-autoPosition='right']"),
                offsetOfEdge = $(".gallery-top .swiper-slide-active").offset().left;

            leftBtn.css({
                left: offsetOfEdge
            });

            rightBtn.css({
                right: offsetOfEdge
            });
        }

        sliderInit();
        sliderItemAutoProperty();
        $(window).resize(sliderInit, sliderItemAutoProperty);
    })();
}

if ($(".recommendationsBlock").length) {
    (() => {
        slidersObj.recommendationsBlock = 0;
        let { recommendationsBlock } = slidersObj,
            swiperWrapper = $(".recommendationsBlock .swiper-wrapper"),
            sliderBtns = $(".recommendationsBlock .swiper-button-prev, .recommendationsBlock .swiper-button-next");

        const slides = $(".recommendationsBlock .swiper-container").find(".swiper-slide");

        function sliderInit() {
            const slidesWidth = Array.from(slides).reduce((accum, el) => (accum += $(el).innerWidth()), 0);

            sliderBtns.css({
                top: slides.find(".cardItem__header").height() / 2
            });

            if (recommendationsBlock === 0 && is("Object", recommendationsBlock) === false && slidesWidth > swiperWrapper.innerWidth()) {
                recommendationsBlock = new Swiper(".recommendationsBlock .swiper-container", {
                    slidesPerView: "auto",
                    navigation: {
                        nextEl: ".recommendationsBlock .swiper-button-next",
                        prevEl: ".recommendationsBlock .swiper-button-prev"
                    }
                });

                sliderBtns.show();
            } else if (recommendationsBlock !== 0 && is("Object", recommendationsBlock) && slidesWidth < swiperWrapper.innerWidth()) {
                recommendationsBlock.destroy();
                recommendationsBlock = 0;

                sliderBtns.hide();
            }
        }

        sliderInit();
        $(window).resize(sliderInit);
    })();
}
