import baron from "baron";
import $ from "jquery";
import { each } from "baron/src/utils";

if ($("[data-baronInit]").length) {
    baron({
        root: "[data-baronInit]", //selector
        scroller: "[data-baronInit] .customScroll__scroller",
        bar: "[data-baronInit] .customScroll__scroller_bar",
        scrollingCls: "_scrolling",
        draggingCls: "_dragging"
    });
}
