//plugins
import "./plugins/dcCustomSelect";
import "./plugins/baronInit";
import "./plugins/sliderInit";

//pages
import "./pages/catalog";
import "./pages/allPage";
import "./pages/productPage";
import "./pages/mainPage";

//Components
import "./components/dropDownAccordion";
import "./components/colorsSelection";
import "./components/toggleInput";
import "./components/tabToggle";
import "./components/headerNavbarBtn";
import "./components/form";
import "./components/cardItem";
import "./components/customInput";
import "./components/switchRegAuthBtn";
import "./components/anchor";

import "./components/coockie";
