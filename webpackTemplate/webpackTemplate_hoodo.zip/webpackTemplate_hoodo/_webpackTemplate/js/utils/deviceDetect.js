export const checkTouchDevice = () => {
    if ("ontouchstart" in window || navigator.msMaxTouchPoints) {
        return true;
    } else {
        return false;
    }
};
