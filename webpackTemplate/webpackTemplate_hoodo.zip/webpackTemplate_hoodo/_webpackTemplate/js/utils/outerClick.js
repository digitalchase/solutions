import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";

export default function outerClick({ event, selector, type, payload }) {
    const div = $(selector);
    if (!div.is(event.target) && div.has(event.target).length === 0) {
        dispatcher({
            type: type,
            payload: payload
        });

        $(document).unbind("click");
    }
}
