import $ from "jquery";

if ($("[data-anchorTo]").length) {
    $("[data-anchorTo]").click(function() {
        const type = $(this).data("anchorto");
        const scrollTo = $(`[data-anchorFrom="${type}"]`).offset().top;

        $("html, body").animate(
            {
                scrollTop: scrollTo
            },
            500
        );
    });
}
