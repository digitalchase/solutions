import $ from "jquery";

$(document).on("click", '[data-action="ADD_TO_CART"]', function(e) {
    e.preventDefault();
    e.stopPropagation();
});

$(document).on("click", '[data-action="ADD_TO_FAVORITE"]', function(e) {
    e.preventDefault();
    e.stopPropagation();
});
