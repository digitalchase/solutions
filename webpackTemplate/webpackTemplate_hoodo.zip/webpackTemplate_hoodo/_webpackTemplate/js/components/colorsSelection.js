import $ from "jquery";
import { dispatcher } from "../dispatcher/index";
import { checkTouchDevice } from "./../utils/deviceDetect";

if ($(".colorsSelection").length) {
    const element = $("[data-colorsSelectionInput]");

    element.on("change", function() {
        const that = $(this);

        const actionType = that.data("action");
        dispatcher({
            type: actionType,
            payload: {
                checked: that.prop("checked"),
                keyColor: that.data("keycolor"),
                title: that.data("colortitle")
            }
        });
    });

    $(document).on("click", '[data-action="TRIGGER_INPUTSELECTION_CHANGE"]', function() {
        const that = $(this);

        const actionType = that.data("action");
        dispatcher({
            type: actionType,
            payload: {
                keyColor: that.data("keycolor")
            }
        });
    });

    // При mouseover показываем тайтл цвета
    $('[data-action="SHOW_COLOR_TITLE"]').on("mouseover", function() {
        if (checkTouchDevice()) return false;

        const that = $(this);
        const _colorTitle = that
            .parent()
            .find("[data-colorTitle]")
            .data("colortitle");

        const actionType = that.data("action");

        dispatcher({
            type: actionType,
            payload: {
                colorTitle: _colorTitle
            }
        });
    });

    // При mouseleave убираем тайтл цвета
    $('[data-action="SHOW_COLOR_TITLE"]').on("mouseleave", function() {
        if (checkTouchDevice()) return false;
        dispatcher({
            type: "REMOVE_COLOR_TITLE"
        });
    });

    $('[data-action="RESET_COLOR_FILTER"]').click(function() {
        dispatcher({
            type: "RESET_COLOR_FILTER"
        });
    });
}
