import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";
import outerClick from "./../utils/outerClick";

(() => {
    $('[data-action="TOGGLE_MENU"]').click(e => {
        e.stopPropagation();

        dispatcher({
            type: "TOGGLE_MENU"
        });

        // Клик вне блока
        $(document).click(event =>
            outerClick({
                event: event,
                selector: '[data-panel="burgerMenu"]',
                type: "CLOSE_MENU"
            })
        );
    });
})();

// Управление попапами которые относятся к header
(() => {
    let lastActionType = "";
    $("[data-headerBtn]").click(function(e) {
        e.stopPropagation();
        const actionType = $(this).data("action");

        if (lastActionType !== actionType && lastActionType !== "") {
            dispatcher({
                type: "CLOSE_ALL_HEADERPOPUP"
            });
        }

        lastActionType = actionType;

        switch (actionType) {
            case "TOGGLE_BASKET_POPUP":
                dispatcher({
                    type: "TOGGLE_BASKET_POPUP",
                    payload: { el: $("[data-basketIcon]") }
                });
                break;

            case "TOGGLE_USER_POPUP_PANEL":
                dispatcher({
                    type: "TOGGLE_USER_POPUP_PANEL",
                    payload: { el: $(`[data-action="TOGGLE_USER_POPUP_PANEL"`) }
                });
                break;
            case "TOGGLE_REGISTRATION_POPUP":
                dispatcher({
                    type: "TOGGLE_REGISTRATION_POPUP",
                    payload: { el: $(`[data-action="TOGGLE_REGISTRATION_POPUP"`) }
                });
                break;
        }

        $(document).click(event => {
            outerClick({
                event: event,
                selector: "[data-headerPopup]",
                type: "CLOSE_ALL_HEADERPOPUP"
            });
        });
    });
})();
