import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";

if ($('[data-action="TAB_TOGGLE"]').length) {
    $('[data-action="TAB_TOGGLE"]').click(function() {
        const that = $(this);
        const tabIndex = that.data("tabindex");

        dispatcher({
            type: "TAB_TOGGLE",
            payload: {
                index: tabIndex,
                el: that
            }
        });
    });
}
