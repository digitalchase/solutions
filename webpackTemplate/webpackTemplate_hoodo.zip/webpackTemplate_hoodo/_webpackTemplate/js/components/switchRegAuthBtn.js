import $ from "jquery";
import { dispatcher } from "./../dispatcher/index";

$('[data-action="SWITCH_REG_AUTH"]').on("click", function() {
  dispatcher({
    type: "SWITCH_REG_AUTH",
    payload: $(this)
  });
});
