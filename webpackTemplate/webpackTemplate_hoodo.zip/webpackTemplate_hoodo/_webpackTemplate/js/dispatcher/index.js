import { accordionToggleDropDown, mobileCatalogAccardion } from "./../action/dropDownAccordion";
import {
    changeColorselection,
    triggerInputselectionChange,
    resetColorFilter,
    showColorTitle,
    removeColorTitle
} from "../action/colorsSelection";
import { tabToggle } from "./../action/tabToggle";
import {
    toggleMenu,
    closeMenu,
    toggleBasketPopup,
    toggleUserPopupPanel,
    closeAllHeaderPopup,
    toggleRegistrationPopup
} from "./../action/headerNavbarBtn";
import { switchRegAuth } from "./../action/switchRegAuth";
import { applyCoockie } from "./../action/coockie";

export const dispatcher = ({ type, payload }) => {
    switch (type) {
        case "ACCORDION_TOGGLE_DROPDOWN":
            accordionToggleDropDown(payload);
            break;
        case "CHANGE_COLORSELECTION":
            changeColorselection(payload);
            break;
        case "TRIGGER_INPUTSELECTION_CHANGE":
            triggerInputselectionChange(payload);
            break;
        case "SHOW_COLOR_TITLE":
            showColorTitle(payload);
            break;
        case "REMOVE_COLOR_TITLE":
            removeColorTitle();
            break;
        case "TAB_TOGGLE":
            tabToggle(payload);
            break;
        case "TOGGLE_MENU":
            toggleMenu();
            break;
        case "TOGGLE_BASKET_POPUP":
            toggleBasketPopup(payload);
            break;
        case "TOGGLE_USER_POPUP_PANEL":
            toggleUserPopupPanel();
            break;
        case "TOGGLE_REGISTRATION_POPUP":
            toggleRegistrationPopup(payload);
            break;
        case "CLOSE_ALL_HEADERPOPUP":
            closeAllHeaderPopup();
            break;
        case "MOBILE_CATALOG_ACCARDION":
            mobileCatalogAccardion(payload);
            break;
        case "RESET_COLOR_FILTER":
            resetColorFilter();
            break;
        case "SWITCH_REG_AUTH":
            switchRegAuth(payload);
            break;
        case "CLOSE_MENU":
            closeMenu();
            break;
        case "APPLY_COOCKIE":
            applyCoockie();
            break;
    }
};
