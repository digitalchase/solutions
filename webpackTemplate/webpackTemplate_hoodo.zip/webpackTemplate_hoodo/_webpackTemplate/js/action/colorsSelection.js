import $ from "jquery";

let colorSelectionList = {};

//Возвращает элемент списка
const colorsSelectionListItem = ({ title, keyColor }) => {
    return `
        <div class="colorsSelection__list_item">
            <div>${title}</div>
            <div class="colorsSelection__list_itemDelete" data-action="TRIGGER_INPUTSELECTION_CHANGE" data-keyColor="${keyColor}">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 8L8 16" stroke="#504C4D" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M8 8L16 16" stroke="#504C4D" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
        </div>
    `;
};

//Создает список элементов
const createColorSelectionList = colors => {
    const container = $("[data-colorSelectionList]");
    const resetBtn = $(".colorsSelection__resetFilter");
    container.empty();

    if (Object.keys(colorSelectionList).length === 0) {
        container.hide();
        resetBtn.hide();

        return false;
    } else if (container.is(":visible") === false) {
        container.show();
        resetBtn.css("display", "flex");
    }

    for (let key in colors) {
        container.append(colorsSelectionListItem({ title: colors[key], keyColor: key }));
    }
};

// Добавляем в объект только выделенные цвета
export const changeColorselection = ({ keyColor, title, checked }) => {
    if (checked) {
        colorSelectionList[keyColor] = title;
    } else {
        delete colorSelectionList[keyColor];
    }

    createColorSelectionList(colorSelectionList);
};

// Убираем checked с соответствующего инпута и вызываем метод для изменения списка
export const triggerInputselectionChange = ({ keyColor }) => {
    $(`input[data-keyColor="${keyColor}"]`).prop("checked", false);
    changeColorselection({ keyColor: keyColor, checked: false });
};

export const showColorTitle = ({ colorTitle }) => {
    $("[data-colorsSelectionColorTitle]").text(colorTitle);
};

export const removeColorTitle = () => {
    $("[data-colorsSelectionColorTitle]").text("");
};

export const resetColorFilter = () => {
    colorSelectionList = {};
    $(`input[data-keyColor]`).prop("checked", false);
    createColorSelectionList(colorSelectionList);
};
