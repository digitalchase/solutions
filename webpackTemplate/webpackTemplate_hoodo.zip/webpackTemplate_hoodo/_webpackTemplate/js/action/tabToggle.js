import $ from "jquery";

export const tabToggle = ({ index, el }) => {
    if ($(`[data-tabContent][data-tabIndex=${index}]`).is(".active")) {
        return false;
    }

    $('[data-action="TAB_TOGGLE"]').removeClass("active");
    el.addClass("active");

    $(`[data-tabContent].active`).removeClass("active");
    $(`[data-tabContent][data-tabIndex=${index}]`).addClass("active");
};
