import $ from "jquery";
import { stopScroll } from "./../utils/stopScroll";
import { dispatcher } from "./../dispatcher/index";

const closeSideMenu = () => {
    const sideMenu = $('[data-panel="burgerMenu"]');
    $(".burger").removeClass("active");
    sideMenu.removeClass("active");
    stopScroll(false);
};

export const closeMenu = () => {
    const sideMenu = $('[data-panel="burgerMenu"]');

    $(".burger").removeClass("active");
    sideMenu.removeClass("active");

    dispatcher({
        type: "CLOSE_ALL_HEADERPOPUP"
    });

    stopScroll(false);
};

export const toggleMenu = () => {
    const sideMenu = $('[data-panel="burgerMenu"]');

    $(".burger").toggleClass("active");
    sideMenu.toggleClass("active");

    dispatcher({
        type: "CLOSE_ALL_HEADERPOPUP"
    });

    if (sideMenu.is(".active")) {
        stopScroll(true);
    } else {
        stopScroll(false);
    }
};

export const closeAllHeaderPopup = () => {
    $("[data-headerBtn].active").removeClass("active");
    $("[data-headerPopUp].active").removeClass("active");
};

export const toggleBasketPopup = ({ el }) => {
    const popUp = $(`[data-headerPopUp="cartPopUp"]`),
        header = $(".header"),
        headerBottom = $(".header__bottom");

    el.toggleClass("active");
    popUp.toggleClass("active");

    const offsetLeft = (headerBottom.innerWidth() - headerBottom.width()) / 2;

    popUp.css({
        top: header.innerHeight() + 20,
        left: headerBottom.width() + offsetLeft + 12 - popUp.innerWidth()
    });

    closeSideMenu();
};

export const toggleUserPopupPanel = ({ el }) => {
    const popUp = $(`[data-headerPopUp="userPanel"]`),
        header = $(".header"),
        headerBottom = $(".header__bottom");

    el.toggleClass("active");
    popUp.toggleClass("active");

    const offsetLeft = (headerBottom.innerWidth() - headerBottom.width()) / 2;

    popUp.css({
        top: header.innerHeight() + 20,
        left: headerBottom.width() + offsetLeft + 12 - popUp.innerWidth()
    });

    closeSideMenu();
};

export const toggleRegistrationPopup = ({ el }) => {
    const popUp = $(`[data-headerPopUp="registrationPopUp"]`),
        header = $(".header"),
        headerBottom = $(".header__bottom");

    el.toggleClass("active");
    popUp.toggleClass("active");

    const offsetLeft = (headerBottom.innerWidth() - headerBottom.width()) / 2;

    popUp.css({
        top: header.innerHeight() + 20,
        left: headerBottom.width() + offsetLeft + 12 - popUp.innerWidth()
    });

    closeSideMenu();
};
