export const accordionToggleDropDown = obj => {
    const { el } = obj;
    const parent = el.parents("[data-accordion]");

    if (parent.find("[data-dropDownContainer]").length === 0) {
        return false;
    }

    parent.toggleClass("active");

    if (parent.is(".active")) {
        el.next("[data-dropDownContainer]").slideDown();
    } else {
        el.next("[data-dropDownContainer]").slideUp();
    }
};

export const mobileCatalogAccardion = obj => {
    const { el } = obj;

    const parent = el.parents("[data-mobileCatalogAccardion]");

    if (parent.find("[data-mobileCatalogAccardionContainer]").length === 0) {
        return false;
    }

    parent.toggleClass("active");

    if (parent.is(".active")) {
        el.next("[data-mobileCatalogAccardionContainer]").slideDown();
    } else {
        el.next("[data-mobileCatalogAccardionContainer]").slideUp();
    }
};
