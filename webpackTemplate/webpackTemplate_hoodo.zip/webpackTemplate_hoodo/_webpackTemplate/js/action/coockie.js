import $ from "jquery";

export const applyCoockie = () => {
    $(".coockieMessage").hide();
};
